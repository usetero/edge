# Changelog

## [0.19.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.18.4...tero-edge-chart-v0.19.0) (2026-10-01)


### Features

* capture failed upstream requests for replay ([#358](https://github.com/usetero/edge/issues/358)) ([c010e92](https://github.com/usetero/edge/commit/c010e923f9363dd3a1cb3d53d99d640ca9b49ed7))


### Bug Fixes

* **capture:** safety fixes for the failure capture ([#359](https://github.com/usetero/edge/issues/359)) ([08020c4](https://github.com/usetero/edge/commit/08020c44f4d2affa6402f8599068ce0deaa6f7d6))

## [0.18.4](https://github.com/usetero/edge/compare/tero-edge-chart-v0.18.3...tero-edge-chart-v0.18.4) (2026-09-25)


### Bug Fixes

* **charts:** sync appVersion to 1.32.1 ([#355](https://github.com/usetero/edge/issues/355)) ([bac11f8](https://github.com/usetero/edge/commit/bac11f86bcbeb74bc775c4ad8d5581ee0d89ee6c))

## [0.18.3](https://github.com/usetero/edge/compare/tero-edge-chart-v0.18.2...tero-edge-chart-v0.18.3) (2026-09-25)


### Performance Improvements

* policy-zig 0.7.4, shared datadog record helpers, and sizing from measurement ([#338](https://github.com/usetero/edge/issues/338)) ([dab019a](https://github.com/usetero/edge/commit/dab019a046286299cf86f7b366bf01948ddea13e))

## [0.18.2](https://github.com/usetero/edge/compare/tero-edge-chart-v0.18.1...tero-edge-chart-v0.18.2) (2026-09-17)


### Bug Fixes

* **charts:** sync appVersion to 1.32.0 ([#333](https://github.com/usetero/edge/issues/333)) ([edf6d38](https://github.com/usetero/edge/commit/edf6d380bf6bc10d32f8a44708aa9b46d7432bfa))

## [0.18.1](https://github.com/usetero/edge/compare/tero-edge-chart-v0.18.0...tero-edge-chart-v0.18.1) (2026-09-15)


### Bug Fixes

* **charts:** sync appVersion to 1.31.0 ([#271](https://github.com/usetero/edge/issues/271)) ([c79dfb5](https://github.com/usetero/edge/commit/c79dfb54c8144d65162a453ab07d106ff3dd16a7))

## [0.18.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.17.6...tero-edge-chart-v0.18.0) (2026-09-15)


### Features

* export httpz connection metrics and fix chart sizing guidance ([#269](https://github.com/usetero/edge/issues/269)) ([f881d7a](https://github.com/usetero/edge/commit/f881d7a716006dc2e08f6a80b59d8afcd148be3a))

## [0.17.6](https://github.com/usetero/edge/compare/tero-edge-chart-v0.17.5...tero-edge-chart-v0.17.6) (2026-09-11)


### Bug Fixes

* **charts:** sync appVersion to 1.30.2 ([#265](https://github.com/usetero/edge/issues/265)) ([8519a7a](https://github.com/usetero/edge/commit/8519a7a972b4b43e701030f48c98ae1a6af8e7b8))

## [0.17.5](https://github.com/usetero/edge/compare/tero-edge-chart-v0.17.4...tero-edge-chart-v0.17.5) (2026-09-11)


### Bug Fixes

* retry replayable log intake on stale upstream connections ([#263](https://github.com/usetero/edge/issues/263)) ([e75cfca](https://github.com/usetero/edge/commit/e75cfca1c49d0ccd902e5e664e07de9c8cfc7828))

## [0.17.4](https://github.com/usetero/edge/compare/tero-edge-chart-v0.17.3...tero-edge-chart-v0.17.4) (2026-09-09)


### Bug Fixes

* **charts:** sync appVersion to 1.30.1 ([#261](https://github.com/usetero/edge/issues/261)) ([2d00eb5](https://github.com/usetero/edge/commit/2d00eb532e56fab87b431c5cbef071ec6b071b41))

## [0.17.3](https://github.com/usetero/edge/compare/tero-edge-chart-v0.17.2...tero-edge-chart-v0.17.3) (2026-09-09)


### Bug Fixes

* **charts:** sync appVersion to 1.30.0 ([#255](https://github.com/usetero/edge/issues/255)) ([ff406ad](https://github.com/usetero/edge/commit/ff406ad5dc2f03882bce4f16efd02e9642138e17))

## [0.17.2](https://github.com/usetero/edge/compare/tero-edge-chart-v0.17.1...tero-edge-chart-v0.17.2) (2026-09-09)


### Bug Fixes

* image tags were incorrectly rendering ([#254](https://github.com/usetero/edge/issues/254)) ([da0d058](https://github.com/usetero/edge/commit/da0d0584255067598a4eaf1ba706b17d0443d454))

## [0.17.1](https://github.com/usetero/edge/compare/tero-edge-chart-v0.17.0...tero-edge-chart-v0.17.1) (2026-07-28)


### Bug Fixes

* **charts:** sync appVersion to 1.29.4 ([#245](https://github.com/usetero/edge/issues/245)) ([b313822](https://github.com/usetero/edge/commit/b31382223c144149505000a4d8f69ac7cbdd273d))

## [0.17.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.16.1...tero-edge-chart-v0.17.0) (2026-07-28)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))
* release please chart sync ([#217](https://github.com/usetero/edge/issues/217)) ([e2f9f64](https://github.com/usetero/edge/commit/e2f9f647370ec6d996ce88ccd4acd03648598d9a))
* update all deps ([#242](https://github.com/usetero/edge/issues/242)) ([aa2d8e2](https://github.com/usetero/edge/commit/aa2d8e27074a38c3fe6d65337e1e180a0cf7bf84))

## [0.16.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.15.2...tero-edge-chart-v0.16.0) (2026-07-16)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))
* release please chart sync ([#217](https://github.com/usetero/edge/issues/217)) ([e2f9f64](https://github.com/usetero/edge/commit/e2f9f647370ec6d996ce88ccd4acd03648598d9a))

## [0.16.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.15.1...tero-edge-chart-v0.16.0) (2026-07-16)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))
* release please chart sync ([#217](https://github.com/usetero/edge/issues/217)) ([e2f9f64](https://github.com/usetero/edge/commit/e2f9f647370ec6d996ce88ccd4acd03648598d9a))

## [0.15.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.14.0...tero-edge-chart-v0.15.0) (2026-07-15)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))
* release please chart sync ([#217](https://github.com/usetero/edge/issues/217)) ([e2f9f64](https://github.com/usetero/edge/commit/e2f9f647370ec6d996ce88ccd4acd03648598d9a))

## [0.13.1](https://github.com/usetero/edge/compare/tero-edge-chart-v0.13.0...tero-edge-chart-v0.13.1) (2026-07-06)


### Bug Fixes

* release please chart sync ([#217](https://github.com/usetero/edge/issues/217)) ([e2f9f64](https://github.com/usetero/edge/commit/e2f9f647370ec6d996ce88ccd4acd03648598d9a))

## [0.13.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.12.0...tero-edge-chart-v0.13.0) (2026-07-06)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))

## [0.11.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.10.1...tero-edge-chart-v0.11.0) (2026-06-30)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))

## [0.11.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.10.0...tero-edge-chart-v0.11.0) (2026-06-29)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))

## [0.9.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.8.0...tero-edge-chart-v0.9.0) (2026-06-24)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))
* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))

## [0.7.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.6.0...tero-edge-chart-v0.7.0) (2026-06-24)


### Features

* **config:** make connection and memory limits configurable ([#198](https://github.com/usetero/edge/issues/198)) ([015cb8d](https://github.com/usetero/edge/commit/015cb8dd4886a25233bcad704b9859f066602e3b))


### Bug Fixes

* add checksum to daemonset for restart ([#196](https://github.com/usetero/edge/issues/196)) ([ebbb626](https://github.com/usetero/edge/commit/ebbb626f2ab04226d99a1bbd11580f331ae29ecb))

## [0.6.0](https://github.com/usetero/edge/compare/tero-edge-chart-v0.5.1...tero-edge-chart-v0.6.0) (2026-06-23)


### Features

* update chart to set resource attrs and labels ([#194](https://github.com/usetero/edge/issues/194)) ([fd32b67](https://github.com/usetero/edge/commit/fd32b67082638ff92b85b0205dcf01b5220f4883))
